package Cuestionario;

import Interfaz.Ventana;

public class cuestionario {

    public static void main(String[] args) {
        
        Ventana obj = new Ventana();
        
    }
    
}




